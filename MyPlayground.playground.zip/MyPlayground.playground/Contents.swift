import UIKit

var greeting = "Hello, playground"

import Foundation


var result = ""
for i in 1...60 {
    if i % 10 == 4 {
        result += String(i)
    }
}
print(result)


// 2.
let hello = "Hello world!"
for ch in hello {
    print(ch)
}


// 3.
let aString1 = "Programming"
if let lastChar = aString1.last {
    print(lastChar)
}


// 4.
let aString2 = "experience"
var replacedString = ""
for ch in aString2 {
    if ch == "e" {
        replacedString.append("*")
    } else {
        replacedString.append(ch)
    }
}
print(replacedString)


// 5.
let aString3 = "Python"
var reverse = ""
let characters = Array(aString3)





for i in stride(from: characters.count - 1, through: 0, by: -1) {
   reverse.append(characters[i])
}
print(reverse)


//6
let aString4 = "madam"
let chars = Array(aString4)
var isPalindrome = true

for i in 0..<chars.count / 2 {
    if chars[i] != chars[chars.count - 1 - i] {
        isPalindrome = false
        break
    }
}
print(isPalindrome)


// 7.
let problem1 = "Learning Swift is fun"
let words1 = problem1.split(separator: " ")

for word in words1 {
    print(word)
}


// 8.
let problem2 = "Learning Swift programming is interesting"
let words2 = problem2.split(separator: " ")

var longestWord = words2[0]
for word in words2 {
    if word.count > longestWord.count {
        longestWord = word
    }
}
print(longestWord)


// 9.
let text = "HelloWorld"
let vowels = "aeiouAEIOU"
var vowelCount = 0
var consonantCount = 0

for ch in text {
    if ch.isLetter {
        if vowels.contains(ch) {
            vowelCount += 1
        } else {
            consonantCount += 1
        }
    }
}

let resultTuple = (vowelCount, consonantCount)
print(resultTuple)


// 10. 
let sentence = "Swift programming language"
let words3 = sentence.split(separator: " ")
let lastWord = words3.last!
print(lastWord.count)
