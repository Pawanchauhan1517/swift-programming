import UIKit

//Q1
let conditionOne = !(4 < 5) || !(3 > 8)
let conditionTwo = !(!true)
if conditionOne {
print("A")
} else if conditionTwo {
print("B")
}
if conditionTwo {
print("C")
}
print("D")

//Q2
let appInfo = (name: "myCoolApp", version: 0.4)
switch appInfo {
case (_, 0.0..<1.0):
print("\(appInfo.0) hasn't released yet")
case ("myCoolApp", _):
print("Thanks for looking at myCoolApp!")
default:
print("I'm not quite sure what you are looking at")
}

//Q3
let x: Int = 4
switch x {
case 0..<4:
print("A")
case 5..<10:
print("B")
case 11...:
print("C")
default:
print("D")
}

//Q4
let candyType : String = "skittles"
switch candyType {
case "mAndM":
print("Melts in your mouth, not in your hand")
case "skittles":
print("Taste the rainbow")
case "snickers":
print("Hungry? Grab a Snickers")
default:
    print("I don't know that candy")
}

//Q5
let currentWeather = "rain"

switch currentWeather {
case "rain":
    print("It's raining")
case "sunny":
    print("It's sunny outside")
case "snow":
    print("It's snowing")
default:
    print("Weather condition not recognized.")
}

//Q6
let firstName = "John"
let lastName = "Appleseed"

let fullName = "\(firstName) \(lastName)"
print("\(fullName)")
//Q7
let temperatureInFahrenheit = 34
switch temperatureInFahrenheit {
case ...40:
    print("It's cold out.")
case 85...:
    print("It's really warm.")
default:
    print("Weather is moderate.")
}

//Q8
let score = 10

if score > 8 {
    print("You win!")
} else {
    print("You lose!")
}

//Q9
var numberOfSides = 6

switch numberOfSides {
case 3:
    print("Triangle")
case 4:
    print("Quadrilateral")
case 5:
    print("Pentagon")
case 6:
    print("Hexagon")
case 7:
    print("Heptagon")
case 8:
    print("Octagon")
case 9:
    print("Nonagon")
case 10:
    print("Decagon")
default:
    print("Error")
}

//10
let numericScore = 88

switch numericScore {
case 100:
    print("A+")
case 90...99:
    print("A")
case 80...89:
    print("B")
case 70...79:
    print("C")
case 65...69:
    print("D")
case 0..<65:
    print("F")
default:
    print("Invalid score")
}

//Q11
let FirstName = "Peter"
var LastName = ""

if FirstName == "Peter" {
    LastName = "Gabriel"
} else if FirstName == "Phil" {
    LastName = "Collins"
}

let FullName = FirstName + " " + LastName
print(FullName)

//Q12
let nameAndBirthYear: (String, Int) = ("Alex", 1998)
let currentYear = 2025
let age = currentYear - nameAndBirthYear.1
if age >= 20 && age < 30 {
    print("You are in your twenties")
} else if age >= 30 && age < 40 {
    print("You are in your thirties")
} else if age >= 40 && age < 50 {
    print("You are in your forties")
} else {
    print("Your decade is outside this range")
}
switch age {
case 20..<30:
    print("You are in your twenties")
case 30..<40:
    print("You are in your thirties")
case 40..<50:
    print("You are in your forties")
default:
    print("Your decade is outside this range")
}

//Q13
let number = 42
switch number {
case 365:
print("Days in year")
case 1024:
print("Bytes in a Kilobyte")
case 0:
print("Where arrays start")
case 42:
print("The answer to life, the universe and everything")
default:
print("Some uninteresting number")
}

//Q14
var population: Int = 10000
var message = String()
if population > 10000 {
    message = "\(population) is a large town"
} else if population > 5000 && population < 10000 {
    message = "\(population) is a medium size town"
} else {
    message = "\(population) is a mid-size town"
}
switch population {
case 10001...:
    message = "\(population) is a large town"
case 5001..<10000:
    message = "\(population) is a medium size town"
default:
    message = "\(population) is a mid-size town"
}

//Q15
let myTuple: (Int, Int) = (5, 10)
let sum = myTuple.0 + myTuple.1
if sum >= 15 {
    print("The sum is at least 15")
} else {
    print("The sum is less than 15")
}
switch sum {
case 15...:
    print("The sum is at least 15")
default:
    print("The sum is less than 15")
}



